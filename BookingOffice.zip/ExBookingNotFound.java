public class ExBookingNotFound extends Exception {
    public ExBookingNotFound(){
        super("Booking not found!");
    }
}
