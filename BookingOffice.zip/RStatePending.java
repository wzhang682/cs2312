public class RStatePending implements RState {
    public String getStatus(){
        return "Pending";
    }
}
