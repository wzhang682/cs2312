public class ExTableCodeNotFound extends Exception{
    public ExTableCodeNotFound(String mess) {
        super(mess);  
    }

}

  