public class ExDatePassed extends Exception {
    public ExDatePassed(){
        super("Date has already passed!");
    }
}
