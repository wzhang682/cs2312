
public interface RState {
    public String getStatus();
    
} 
