public class ExWrongNumberFormat extends Exception { 
    public ExWrongNumberFormat() {
         super("Wrong number format!"); 

}} 
    