public class ExInsufficientArguments extends Exception { 
    public ExInsufficientArguments() 
    { super("Insufficient command arguments!"); } 
    } 
