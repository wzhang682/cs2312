public interface Command {
    public void execute(String[] cmdParts);
}